import entities.Address;
import entities.Town;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.util.List;
import java.util.Scanner;

public class moveTowns13 {
    public static void main(String[] args) {

        EntityManagerFactory factory = Persistence.createEntityManagerFactory("soft_uni");
        EntityManager manager = factory.createEntityManager();

        Scanner scanner = new Scanner(System.in);
        String townToDelete = scanner.nextLine();

        manager.getTransaction().begin();

        List<Address> townDelete = manager.createQuery("SELECT a FROM Address a " +
                                "WHERE a.town.name = :townDelete"
                        , Address.class)
                .setParameter("townDelete", townToDelete)
                .getResultList();

        int count = 0;
        for (Address address : townDelete) {
            count++;
            manager.remove(address);
        }
        manager.getTransaction().commit();

        System.out.println(count > 1 ? count + " addresses in " + townDelete + " deleted"
                : count + " address in " + townDelete + " deleted");

        manager.close();
    }
}

